﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="HospitalManagementSystem.Dashboard" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Hospital Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f7fb;
        }

        .navbar {
            background: #0d6efd;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .card {
            border: none;
            border-radius: 12px;
        }

        .stat-number {
            font-size: 35px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">

            <a class="navbar-brand fw-bold" href="Dashboard.aspx">
                🏥 Hospital Management
            </a>

            <div>
                <a class="nav-link d-inline-block" href="Dashboard.aspx">
                    Dashboard
                </a>

                <a class="nav-link d-inline-block" href="Doctors.aspx">
                    Doctors
                </a>

                <a class="nav-link d-inline-block" href="Patients.aspx">
                    Patients
                </a>

                <a class="nav-link d-inline-block" href="Appointments.aspx">
                    Appointments
                </a>

                <a class="nav-link d-inline-block" href="Login.aspx">
                    Logout
                </a>
            </div>

        </div>
    </nav>

   <div class="container mt-5">

    <h2 class="fw-bold mb-2">🏥 Hospital Dashboard</h2>

    <p class="text-muted mb-4">
        Welcome to Hospital Management System
    </p>

    <!-- Statistics -->

    <div class="row">

        <div class="col-md-3 mb-4">

            <div class="card shadow-sm p-4 text-center">

                <div style="font-size:40px;">👨‍⚕️</div>

                <h2 class="text-primary">25</h2>

                <p class="text-muted mb-0">
                    Total Doctors
                </p>

            </div>

        </div>

        <div class="col-md-3 mb-4">

            <div class="card shadow-sm p-4 text-center">

                <div style="font-size:40px;">🧑</div>

                <h2 class="text-success">150</h2>

                <p class="text-muted mb-0">
                    Total Patients
                </p>

            </div>

        </div>

        <div class="col-md-3 mb-4">

            <div class="card shadow-sm p-4 text-center">

                <div style="font-size:40px;">📅</div>

                <h2 class="text-warning">18</h2>

                <p class="text-muted mb-0">
                    Appointments
                </p>

            </div>

        </div>

        <div class="col-md-3 mb-4">

            <div class="card shadow-sm p-4 text-center">

                <div style="font-size:40px;">🏨</div>

                <h2 class="text-danger">12</h2>

                <p class="text-muted mb-0">
                    Available Rooms
                </p>

            </div>

        </div>

    </div>


    <!-- Quick Actions -->

    <div class="card shadow-sm mb-4">

        <div class="card-body">

            <h4 class="mb-3">Quick Actions</h4>

            <a href="Doctors.aspx"
               class="btn btn-primary me-2">
                👨‍⚕️ Manage Doctors
            </a>

            <a href="Patients.aspx"
               class="btn btn-success me-2">
                🧑 Manage Patients
            </a>

            <a href="Appointments.aspx"
               class="btn btn-warning">
                📅 Manage Appointments
            </a>

        </div>

    </div>


    <!-- Today's Appointments -->

    <div class="card shadow-sm">

        <div class="card-body">

            <h4 class="mb-3">
                📅 Today's Appointments
            </h4>

            <div class="table-responsive">

                <table class="table table-hover">

                    <thead class="table-primary">

                        <tr>

                            <th>Patient</th>

                            <th>Doctor</th>

                            <th>Time</th>

                            <th>Status</th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr>

                            <td>Rahul Kumar</td>

                            <td>Dr. Smith</td>

                            <td>10:00 AM</td>

                            <td>
                                <span class="badge bg-success">
                                    Confirmed
                                </span>
                            </td>

                        </tr>

                        <tr>

                            <td>Priya Sharma</td>

                            <td>Dr. John</td>

                            <td>11:30 AM</td>

                            <td>
                                <span class="badge bg-warning text-dark">
                                    Pending
                                </span>
                            </td>

                        </tr>

                        <tr>

                            <td>Arun Kumar</td>

                            <td>Dr. David</td>

                            <td>02:00 PM</td>

                            <td>
                                <span class="badge bg-success">
                                    Confirmed
                                </span>
                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>
</form>

</body>
</html>
