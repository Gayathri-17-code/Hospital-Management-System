﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Appointments.aspx.cs" Inherits="HospitalManagementSystem.Appointments" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Appointments</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f7fb;
        }

        .navbar {
            background: #0d6efd;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .card {
            border: none;
            border-radius: 12px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <nav class="navbar">
        <div class="container">

            <a class="navbar-brand fw-bold" href="Dashboard.aspx">
                🏥 Hospital Management
            </a>

            <div>

                <a class="nav-link d-inline-block" href="Dashboard.aspx">
                    Dashboard
                </a>

                <a class="nav-link d-inline-block" href="Doctors.aspx">
                    Doctors
                </a>

                <a class="nav-link d-inline-block" href="Patients.aspx">
                    Patients
                </a>

                <a class="nav-link d-inline-block" href="Appointments.aspx">
                    Appointments
                </a>

                <a class="nav-link d-inline-block" href="Login.aspx">
                    Logout
                </a>

            </div>

        </div>
    </nav>

    <div class="container mt-5">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <h2>📅 Appointments</h2>

  <asp:Button ID="btnAddAppointment"
    runat="server"
    Text="+ New Appointment"
    CssClass="btn btn-primary"
    OnClick="btnAddAppointment_Click" />          

        </div>
        <asp:Panel ID="pnlAppointmentForm"
    runat="server"
    Visible="false">

    <div class="card shadow-sm mb-4">

        <div class="card-body">

            <h4>📅 New Appointment</h4>

            <div class="row mt-3">

                <!-- Patient -->
                <div class="col-md-6 mb-3">

                    <label>Patient Name</label>

                    <asp:DropDownList ID="ddlPatient"
                        runat="server"
                        CssClass="form-control">

                        <asp:ListItem>Select Patient</asp:ListItem>
                        <asp:ListItem>Rahul Kumar</asp:ListItem>
                        <asp:ListItem>Priya Sharma</asp:ListItem>
                        <asp:ListItem>Arun Kumar</asp:ListItem>
                        <asp:ListItem>Anjali Devi</asp:ListItem>

                    </asp:DropDownList>

                </div>

                <!-- Doctor -->
                <div class="col-md-6 mb-3">

                    <label>Doctor</label>

                    <asp:DropDownList ID="ddlDoctor"
                        runat="server"
                        CssClass="form-control">

                        <asp:ListItem>Select Doctor</asp:ListItem>
                        <asp:ListItem>Dr. Smith</asp:ListItem>
                        <asp:ListItem>Dr. John</asp:ListItem>
                        <asp:ListItem>Dr. Sarah</asp:ListItem>
                        <asp:ListItem>Dr. David</asp:ListItem>

                    </asp:DropDownList>

                </div>

                <!-- Date -->
                <div class="col-md-6 mb-3">

                    <label>Appointment Date</label>

                    <asp:TextBox ID="txtAppointmentDate"
                        runat="server"
                        TextMode="Date"
                        CssClass="form-control">
                    </asp:TextBox>

                </div>

                <!-- Time -->
                <div class="col-md-6 mb-3">

                    <label>Appointment Time</label>

                    <asp:TextBox ID="txtAppointmentTime"
                        runat="server"
                        TextMode="Time"
                        CssClass="form-control">
                    </asp:TextBox>

                </div>

            </div>

            <asp:Button ID="btnSaveAppointment"
                runat="server"
                Text="Save Appointment"
                CssClass="btn btn-success"
                OnClick="btnSaveAppointment_Click" />

        </div>

    </div>

</asp:Panel>

        <div class="card shadow-sm">

            <div class="card-body">

                <table class="table table-hover">

                    <thead class="table-primary">

                        <tr>
                            <th>ID</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>

                    </thead>

                    <tbody>

                        <tr>
                            <td>1</td>
                            <td>Rahul Kumar</td>
                            <td>Dr. Smith</td>
                            <td>05-Oct-2026</td>
                            <td>10:00 AM</td>
                            <td>
                                <span class="badge bg-success">
                                    Confirmed
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>2</td>
                            <td>Priya Sharma</td>
                            <td>Dr. John</td>
                            <td>05-Oct-2026</td>
                            <td>11:30 AM</td>
                            <td>
                                <span class="badge bg-warning text-dark">
                                    Pending
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>3</td>
                            <td>Arun Kumar</td>
                            <td>Dr. David</td>
                            <td>05-Oct-2026</td>
                            <td>02:00 PM</td>
                            <td>
                                <span class="badge bg-success">
                                    Confirmed
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>4</td>
                            <td>Anjali Devi</td>
                            <td>Dr. Sarah</td>
                            <td>06-Oct-2026</td>
                            <td>09:30 AM</td>
                            <td>
                                <span class="badge bg-danger">
                                    Cancelled
                                </span>
                            </td>
                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</form>

</body>
</html>