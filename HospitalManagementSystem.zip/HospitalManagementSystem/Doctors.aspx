﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Doctors.aspx.cs" Inherits="HospitalManagementSystem.Doctors" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Doctors</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f7fb;
        }

        .navbar {
            background: #0d6efd;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .card {
            border: none;
            border-radius: 12px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">

            <a class="navbar-brand fw-bold" href="Dashboard.aspx">
                🏥 Hospital Management
            </a>

            <div>
                <a class="nav-link d-inline-block" href="Dashboard.aspx">
                    Dashboard
                </a>

                <a class="nav-link d-inline-block" href="Doctors.aspx">
                    Doctors
                </a>

                <a class="nav-link d-inline-block" href="Patients.aspx">
                    Patients
                </a>

                <a class="nav-link d-inline-block" href="Appointments.aspx">
                    Appointments
                </a>

                <a class="nav-link d-inline-block" href="Login.aspx">
                    Logout
                </a>
            </div>

        </div>
    </nav>

    <div class="container mt-5">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <h2>👨‍⚕️ Doctors</h2>

          <asp:Button ID="btnAddDoctor"
    runat="server"
    Text="+ Add Doctor"
    CssClass="btn btn-primary"
    OnClick="btnAddDoctor_Click" />  

        </div>
<asp:Panel ID="pnlDoctorForm" runat="server" Visible="false">

    <div class="card shadow-sm mb-4">

        <div class="card-body">

            <h4>Add New Doctor</h4>

            <div class="row mt-3">

                <div class="col-md-4 mb-3">
                    <label>Doctor Name</label>

                    <asp:TextBox ID="txtDoctorName"
                        runat="server"
                        CssClass="form-control"
                        placeholder="Enter doctor name">
                    </asp:TextBox>
                </div>

                <div class="col-md-4 mb-3">
                    <label>Specialization</label>

                    <asp:TextBox ID="txtSpecialization"
                        runat="server"
                        CssClass="form-control"
                        placeholder="Enter specialization">
                    </asp:TextBox>
                </div>

                <div class="col-md-4 mb-3">
                    <label>Phone</label>

                    <asp:TextBox ID="txtDoctorPhone"
                        runat="server"
                        CssClass="form-control"
                        placeholder="Enter phone">
                    </asp:TextBox>
                </div>

            </div>

            <asp:Button ID="btnSaveDoctor"
                runat="server"
                Text="Save Doctor"
                CssClass="btn btn-success"
                OnClick="btnSaveDoctor_Click" />

        </div>

    </div>

</asp:Panel>

        <div class="card shadow-sm">

            <div class="card-body">

                <table class="table table-hover">

                    <thead class="table-primary">

                        <tr>
                            <th>ID</th>
                            <th>Doctor Name</th>
                            <th>Specialization</th>
                            <th>Phone</th>
                            <th>Status</th>
                        </tr>

                    </thead>

                    <tbody>

                        <tr>
                            <td>1</td>
                            <td>Dr. Smith</td>
                            <td>Cardiologist</td>
                            <td>9876543210</td>
                            <td>
                                <span class="badge bg-success">
                                    Available
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>2</td>
                            <td>Dr. John</td>
                            <td>Neurologist</td>
                            <td>9876543211</td>
                            <td>
                                <span class="badge bg-success">
                                    Available
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>3</td>
                            <td>Dr. Sarah</td>
                            <td>Pediatrician</td>
                            <td>9876543212</td>
                            <td>
                                <span class="badge bg-danger">
                                    Busy
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td>4</td>
                            <td>Dr. David</td>
                            <td>Orthopedic</td>
                            <td>9876543213</td>
                            <td>
                                <span class="badge bg-success">
                                    Available
                                </span>
                            </td>
                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</form>

</body>
</html>
