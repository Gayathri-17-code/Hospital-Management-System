﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="HospitalManagementSystem.Login" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Hospital Management System - Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #eef4f8;
        }

        .login-box {
            width: 400px;
            margin: 100px auto;
            padding: 35px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }

        .hospital-icon {
            font-size: 55px;
            text-align: center;
        }

        h2 {
            text-align: center;
            color: #0d6efd;
            margin-bottom: 25px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <div class="login-box">

        <div class="hospital-icon">🏥</div>

        <h2>Hospital Management</h2>

        <div class="mb-3">
            <label>Username</label>
            <asp:TextBox ID="txtUsername"
                runat="server"
                CssClass="form-control"
                placeholder="Enter username">
            </asp:TextBox>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <asp:TextBox ID="txtPassword"
                runat="server"
                TextMode="Password"
                CssClass="form-control"
                placeholder="Enter password">
            </asp:TextBox>
        </div>

        <asp:Button ID="btnLogin"
            runat="server"
            Text="Login"
            CssClass="btn btn-primary w-100"
            OnClick="btnLogin_Click" />

        <asp:Label ID="lblMessage"
            runat="server"
            CssClass="text-danger d-block text-center mt-3">
        </asp:Label>

        <p class="text-muted text-center mt-3">
            Demo: admin / admin123
        </p>

    </div>

</form>

</body>
</html>