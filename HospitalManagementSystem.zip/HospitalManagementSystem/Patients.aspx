﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Patients.aspx.cs" Inherits="HospitalManagementSystem.Patients" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Patients</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f7fb;
        }

        .navbar {
            background: #0d6efd;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .card {
            border: none;
            border-radius: 12px;
        }
    </style>
</head>

<body>

<form id="form1" runat="server">

    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">

            <a class="navbar-brand fw-bold" href="Dashboard.aspx">
                🏥 Hospital Management
            </a>

            <div>
                <a class="nav-link d-inline-block" href="Dashboard.aspx">
                    Dashboard
                </a>

                <a class="nav-link d-inline-block" href="Doctors.aspx">
                    Doctors
                </a>

                <a class="nav-link d-inline-block" href="Patients.aspx">
                    Patients
                </a>

                <a class="nav-link d-inline-block" href="Appointments.aspx">
                    Appointments
                </a>

                <a class="nav-link d-inline-block" href="Login.aspx">
                    Logout
                </a>
            </div>

        </div>
    </nav>

    <div class="container mt-5">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <h2>🧑 Patients</h2>

            <asp:Button ID="btnAddPatient"
    runat="server"
    Text="+ Add Patient"
    CssClass="btn btn-primary"
    OnClick="btnAddPatient_Click" />

        </div>
        <asp:Panel ID="pnlPatientForm" runat="server" Visible="false">

    <div class="card shadow-sm mb-4">

        <div class="card-body">

            <h4>Add New Patient</h4>

            <div class="row mt-3">

                <div class="col-md-4 mb-3">
                    <label>Patient Name</label>
                    <asp:TextBox ID="txtPatientName"
                        runat="server"
                        CssClass="form-control">
                    </asp:TextBox>
                </div>

                <div class="col-md-2 mb-3">
                    <label>Age</label>
                    <asp:TextBox ID="txtAge"
                        runat="server"
                        CssClass="form-control">
                    </asp:TextBox>
                </div>

                <div class="col-md-3 mb-3">
                    <label>Gender</label>
                    <asp:DropDownList ID="ddlGender"
                        runat="server"
                        CssClass="form-control">

                        <asp:ListItem>Male</asp:ListItem>
                        <asp:ListItem>Female</asp:ListItem>

                    </asp:DropDownList>
                </div>

                <div class="col-md-3 mb-3">
                    <label>Phone</label>
                    <asp:TextBox ID="txtPatientPhone"
                        runat="server"
                        CssClass="form-control">
                    </asp:TextBox>
                </div>

            </div>

            <div class="mb-3">

                <label>Problem / Disease</label>

                <asp:TextBox ID="txtProblem"
                    runat="server"
                    CssClass="form-control"
                    placeholder="Enter patient problem">
                </asp:TextBox>

            </div>

            <asp:Button ID="btnSavePatient"
                runat="server"
                Text="Save Patient"
                CssClass="btn btn-success"
                OnClick="btnSavePatient_Click" />

        </div>

    </div>

</asp:Panel>

        <div class="card shadow-sm">

            <div class="card-body">

                <table class="table table-hover">

                    <thead class="table-primary">

                        <tr>
                            <th>ID</th>
                            <th>Patient Name</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Problem</th>
                        </tr>

                    </thead>

                    <tbody>

                        <tr>
                            <td>1</td>
                            <td>Rahul Kumar</td>
                            <td>35</td>
                            <td>Male</td>
                            <td>9876500001</td>
                            <td>Heart Problem</td>
                        </tr>

                        <tr>
                            <td>2</td>
                            <td>Priya Sharma</td>
                            <td>28</td>
                            <td>Female</td>
                            <td>9876500002</td>
                            <td>Fever</td>
                        </tr>

                        <tr>
                            <td>3</td>
                            <td>Arun Kumar</td>
                            <td>45</td>
                            <td>Male</td>
                            <td>9876500003</td>
                            <td>Back Pain</td>
                        </tr>

                        <tr>
                            <td>4</td>
                            <td>Anjali Devi</td>
                            <td>31</td>
                            <td>Female</td>
                            <td>9876500004</td>
                            <td>Migraine</td>
                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</form>

</body>
</html>