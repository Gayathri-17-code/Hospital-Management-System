﻿using System;

namespace HospitalManagementSystem
{
    public partial class Patients : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnAddPatient_Click(object sender, EventArgs e)
        {
            pnlPatientForm.Visible = true;
        }

        protected void btnSavePatient_Click(object sender, EventArgs e)
        {
            pnlPatientForm.Visible = false;

            Response.Write("<script>alert('Patient added successfully!');</script>");
        }
    }
}