﻿using System;

namespace HospitalManagementSystem
{
    public partial class Appointments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnAddAppointment_Click(object sender, EventArgs e)
        {
            pnlAppointmentForm.Visible = true;
        }

        protected void btnSaveAppointment_Click(object sender, EventArgs e)
        {
            pnlAppointmentForm.Visible = false;

            Response.Write(
                "<script>alert('Appointment booked successfully!');</script>"
            );
        }
    }
}